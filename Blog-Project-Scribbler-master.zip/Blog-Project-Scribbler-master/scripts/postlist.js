const deletePost1 = () => {
    document.getElementById("post1").style.display="none"
  };    
  const deletePost2 = () => {
    document.getElementById("post2").style.display="none"
  };  
  const deletePost3 = () => {
    document.getElementById("post3").style.display="none"
  };  
  const deletePost4 = () => {
    document.getElementById("post4").style.display="none"
  };  
  const deletePost5 = () => {
    document.getElementById("post5").style.display="none"
  };  